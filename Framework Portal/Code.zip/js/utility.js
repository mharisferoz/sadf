$(function() {
    if(localStorage.user==undefined){
        // if( window.location.href.indexOf('register.html') != -1){
        //     return false;
        // }
        if( window.location.href.indexOf('index.html') == -1 && window.location.href.indexOf('register.html') == -1){
            window.location.href="index.html";
            return false;
        }
    }
    else{
        if(window.location.href.indexOf('dashboard.html') > 0){
            getApplication(); 
        }
        if(window.location.href.indexOf('Profile.html') > 0){
            var user = JSON.parse(localStorage.user); 
            $('#Name').val(user.name);
            $('#inputEmail').val(user.email);
            $('#Mobile').val(user.mobile);
            $('#Address').val(user.address);
            $('#userName').val(user.username);
            $('#Password').val(user.password);
            $('#confirmPassword').val(user.password);
            // var dt =user.dob;
            // dt = dt.split('-');
            // dt = dt[2]+"-"+dt[1]+"-"+dt[0];
            // $('#dob').val(dt);
            $('#dob').val(user.dob);
            // $('#Name').val(user.name);
        }
        if(window.location.href.indexOf('app.html') > 0){
            getVersionByApplicationId();
            getApplicationById(); 
            var application = JSON.parse(localStorage.application); 
            $('.card-header').text(application.name);
        }
        
    }
 });

// var Base_URL = "http://localhost/Projects/haris/SecureAppDeployementApi/";
// var API_URL= Base_URL+"service.php";
// var UPLOAD_URL= Base_URL+"upload_image.php";
// var MEDIA_URL= Base_URL+"uploads/";

// var Base_URL = "http://secureappdeployment.epizy.com/api/";
var Base_URL = "http://harisferoz.com/api/";
var API_URL= Base_URL+"service.php";
var UPLOAD_URL= Base_URL+"upload_image.php";
var UPLOAD_APK_URL= Base_URL+"upload_apk.php";
var MEDIA_URL= Base_URL+"uploads/";



function PostAPI(data,callback){
    $('#cover-spin').show();
    // $('body').loading('stop');
    $.ajax({
        type: "POST",
        url: API_URL,
        data: data,
        contentType: "application/x-www-form-urlencoded",
        dataType: "json",
        transformRequest: function (obj) {
            var str = [];
            for (var p in obj)
                str.push(p + "=" + obj[p]);
            return str.join("&");
        },
        success: function(data){
            $('#cover-spin').hide();
            // $('body').loading('stop');
            if(data.success==true){
                callback(data);
            }
            else{
                $('.modal-body').text(data.message);
                $('#logoutModal').modal('show'); 
                // alert(data.message);
            }

        },
        failure: function(errMsg) {
            console.log(errMsg);
        }
  });
}
function FillImg(imgid,inputid,ths){
    var path = URL.createObjectURL(ths.files[0]);
    $(imgid).attr('src',path);
}
function openfile(inputfile){
    $(inputfile).trigger('click');
}
function deleteSC(imgid,inputid){
    $(imgid).attr('src','img/upload-sc.png');
    $(inputid).val('');
}
function logout(){
    delete localStorage.application;
    delete localStorage.user;
    delete localStorage.devices;
}
function login(){
    var data={
        "action": "login",
        "email": $('#inputEmail').val(),
        "password": $('#inputPassword').val()
    }
    PostAPI(data,function(result){
        localStorage.user=JSON.stringify(result.user);
        window.location.href="dashboard.html";
    })
}
function signup(){
    event.preventDefault();
    if($('#Password').val() != $('#confirmPassword').val()){
        $('.modal-body').text('Password and Confirm Password are not same.');
        $('#logoutModal').modal('show'); 
        // alert('Password and Confirm Password are not same.');
    }
    var data={
        "action": "signup",
        "name": $('#Name').val(),
        "email": $('#inputEmail').val(),
        "mobile": $('#Mobile').val(),
        "address": $('#Address').val(),
        "active": 1,
        "username": $('#userName').val(),
        "password": $('#Password').val(),
        "dob": $('#dob').val(),
        "image": ""
    }
    console.log(data);
    PostAPI(data,function(result){
        localStorage.user=JSON.stringify(result.user);
        window.location.href="dashboard.html";
    })
}
function updateProfile(){
    event.preventDefault();
    if($('#Password').val() != $('#confirmPassword').val()){
        $('.modal-body').text('Password and Confirm Password are not same.');
        $('#logoutModal').modal('show'); 
        // alert('Password and Confirm Password are not same.');
    }
    var user = JSON.parse(localStorage.user);
    var data={
        "action": "editProfile",
        "id": user.iduser,
        "name": $('#Name').val(),
        "email": $('#inputEmail').val(),
        "mobile": $('#Mobile').val(),
        "address": $('#Address').val(),
        "username": $('#userName').val(),
        "password": $('#Password').val(),
        "dob": $('#dob').val(),
        "image": ""
    }
    console.log(data);
    PostAPI(data,function(resu){
        var data={
            "action": "login",
            "email": $('#inputEmail').val(),
            "password": $('#Password').val()
        }
        PostAPI(data,function(result){
            localStorage.user=JSON.stringify(result.user);
            $('.modal-body').text('Profile updated succefully.');
            $('#logoutModal').modal('show'); 
            // alert('Profile updated succefully.');
            // window.location.href="dashboard.html";
        })
        // localStorage.user=JSON.stringify(result.user);
        // window.location.href="dashboard.html";
    })
}
function InitializeApp(obj){
    localStorage.application = JSON.stringify(obj);
    // $('#myModal').modal(options)
    getDevices(obj);
}
function getDevices(obj){
    var data={
        "action": "getDevices",
        "idapplication": obj['idapplication']
    }
    PostAPI(data,function(result){
        if(result.data.length==0){
            $('#devices').html('<option value="" disabled>Choose...</option>');
        }
        else{
            localStorage.devices = JSON.stringify(result.data);
            var option = '<option value="" disabled>Choose...</option><option value="all">All</option>';
            var apps=result.data;
            for(var a in apps){
                option += "<option value="+apps[a]['id']+">"+apps[a]['deviceid']+"</option>";
            }
            $('#devices').html(option);
            $('#devices').selectpicker();
        }
    })
}
function distribute(){
    if($('#devices').val() == ""){
        $('.logoutbody').text('Please select atleast one device id.');
        $('#logoutModal').modal('show');
        return false;
    }
    var ids = "";
    if($('#devices').val().join().indexOf('all') != -1){
        var data = JSON.parse(localStorage.devices);
        for(var a = 0 ;a<data.length;a++){
            if(a == 1){
                ids += data[a]['id'];
            }
            else{
                ids += "," + data[a]['id'];
            }
        }
    }
    else{
        ids = $('#devices').val().join();
    }
    var data={
        "action": "updateDevices",
        "id": ids
    }
    PostAPI(data,function(result){
        $('#distributeModal').modal('hide');
        $('.logoutbody').text(result.message);
        $('#logoutModal').modal('show');
    })
}
function getApplication(){
    var user=JSON.parse(localStorage.user);
    var data={
        "action": "getApplicationsOnly",
        "id": user.iduser
    }
    PostAPI(data,function(result){
        if(result.data.length==0){
            $('#appTableBody').html('<tr><td></td><td></td><td></td><td></td><td></td></tr>');
        }
        else{            
            $('#appTableBody').html('');
            var apps=result.data;
            for(var a in apps){
                var temp="<tr><td>"+apps[a]['name']+"</td><td>"+apps[a]['uniqueKey']+"</td><td>"+apps[a]['date']+"</td><td><a class='actionbtn' onclick='EditApp("+JSON.stringify(apps[a])+")'>Details</a></td>"+
                "<td><a class='actionbtn' onclick='DeleteApp("+JSON.stringify(apps[a])+")'>Delete</a></td></tr>";
                $('#appTableBody').append(temp);
            }
        }
    })
}
function getVersionByApplicationId(){
    var application=JSON.parse(localStorage.application);
    var data={
        "action": "getNewVersion",
        "idapp": application.idapplication,
    }
    PostAPI(data,function(result){
        if(result.success==true){
            $('#Version').val(result.data.version);
        }
        else{
           
        }
    })
}
function getApplicationById(){
    var user=JSON.parse(localStorage.user);
    var application=JSON.parse(localStorage.application);
    var data={
        "action": "getApplicationsById",
        "id": user.iduser,
        "idapp": application.idapplication,
    }
    PostAPI(data,function(result){
        console.log(result);
        
        if(result.data.length==0){
            $('#appTableBody').html('<tr><td></td><td></td><td></td><td></td></tr>');
        }
        else{
            
            $('#appTableBody').html('');
            var apps=result.data;
            for(var a in apps){
                var file =apps[a]['link'];
                var filename =apps[a]['name'];
                var temp="<tr><td>"+apps[a]['version']+"</td><td>"+apps[a]['date']+
                "</td><td><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#distributeModal' onclick='InitializeApp("+JSON.stringify(apps[a])+")'>Distribute</button></td><td><a class='actionbtn' href='"+file+"' target='_blank'>"+filename+"</a></td>"+
                "<td><a class='actionbtn' onclick='deleteVersion("+JSON.stringify(apps[a])+")'>Delete</a></td></tr>";
                $('#appTableBody').append(temp);
            }
        }
    })
}
function EditApp(obj){
    localStorage.application=JSON.stringify(obj);
    console.log(obj);
    window.location.href="app.html";
}
function Alert(obj){
    
}
function DeleteApp(obj){
    console.log(obj.version);

    var data={
        "action": "deleteApplication",
        "idapplication": obj.idapplication,
        "iduser": obj.iduser
    }
    PostAPI(data,function(result){
        // alert(result.message);
        $('.modal-body').text('Application deleted successfully.');
        $('#logoutModal').modal('show');
        if(!alert(result.message)){
            window.location.href="dashboard.html";
        }
    })
}
function deleteVersion(obj){
    console.log(obj);
    var user=JSON.parse(localStorage.user);
    var data={
        "action": "deleteVersion",
        "idversions": obj.idversions,
        "iduser": obj.iduser
    }
    PostAPI(data,function(result){
        getApplicationById();
        $('.modal-body').text(result.message);
        $('#logoutModal').modal('show'); 
        // alert(result.message);
    })
}
function getBase64(file,callback) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      console.log(reader.result);
      callback(reader.result);
    };
    reader.onerror = function (error) {
        callback('');
      console.log('Error: ', error);
    };
 }
function addApp(obj){
    // event.preventDefault();
    $('#cover-spin').show();
    var user=JSON.parse(localStorage.user);
    var data={
        "action": "addApplication",
        "name": $('#Name').val(),
        "description": $('#Description').val(),
        "logo":obj.logo,
        "sc1":obj.sc1,
        "sc2":obj.sc2,
        "sc3":obj.sc3,
        "category": $('#Category').val(),
        "web": $('#Web').val(),
        "id": user.iduser
    };
    PostAPI(data,function(result){
        $('#cover-spin').hide();
        if(result.success ==  true){
            $('.modal-body').text('Application added successfully.');
            $('#logoutModal').modal('show');
            $('#logoutModal').on('hidden.bs.modal', function (e) {
                window.location.href = 'dashboard.html';
            });
        }
        else{
            $('.modal-body').text(result.message);
        }
      
        // alert(result.message);
        // if(!alert(result.message)){
        //     window.location.href="dashboard.html";
        // }
        
    });
}
function upload(){
    $('#cover-spin').show();
    // $('body').loading();
    // console.log($('#exampleFormControlFile1')[0]['files']);
    var image = "";
    getBase64($('#exampleFormControlFile1')[0].files[0],function(img){
        // image = img;
        // console.log(image);
        var sdata ={
            "image":img
        }
        $.ajax({
            type: "POST",
            url: UPLOAD_APK_URL,
            data: sdata,
            contentType: "application/x-www-form-urlencoded",
            dataType: "json",
            transformRequest: function (obj) {
                var str = [];
                for (var p in obj)
                    str.push(p + "=" + obj[p]);
                return str.join("&");
            },
            success: function(data){
                $('#cover-spin').hide();
                // var data =JSON.parse(data);
                if(data.success == true){
                    addVersion(data.File)
                }
            },
            failure: function(errMsg) {
                console.log(errMsg);
            }
        })
    });
    // var formData = new FormData();
    // formData.append('fileName', $('#exampleFormControlFile1')[0].files[0]);
    // formData.append('imageName',"apk");
    // $.ajax({
    //     url: UPLOAD_URL,
    //     data: formData,
    //     async: false,
    //     contentType: false,
    //     processData: false,
    //     cache: false,
    //     type: 'POST',
    //     success: function(data){
    //         $('#cover-spin').hide();
    //         // $('body').loading('stop');
    //         var data =JSON.parse(data);
    //         if(data.success == true){
    //             addVersion(data.File)
    //         }
    //         console.log(data);
    //     }
    // })
}
function uploadSC(){
    $('#cover-spin').show();
    var count = 0;
    var obj = {
        "logo":"",
        "sc1":"",
        "sc2":"",
        "sc3":""
    }
    for(var a=1; a<=4 ;a++ ){
        var formData = new FormData();
        var fileName = "";
        if(a == 1 ){
            fileName = "#logoinput";
        }
        else{
            fileName = "#scfile"+(a-1);
        } 
        formData.append('fileName', $(fileName)[0].files[0]);
        formData.append('imageName',"test");
        $.ajax({
            url: UPLOAD_URL,
            data: formData,
            async: false,
            contentType: false,
            processData: false,
            cache: false,
            type: 'POST',
            success: function(data){
                var data =JSON.parse(data);
                if(data.success == true){
                    count++;
                    if(count == 1 ){
                        obj['logo'] = data.File;
                    }
                    if(count == 2 ){
                        obj['sc1'] = data.File;
                    }
                    if(count == 3 ){
                        obj['sc2'] = data.File;
                    }
                    if(count == 4 ){
                        $('#cover-spin').hide();
                        obj['sc3'] = data.File;
                        addApp(obj);
                        // return false;
                    } 
                }
                else{
                    $('#cover-spin').hide();
                }
            }
        })
    }
}
function addVersion(file){
    event.preventDefault();
    var user=JSON.parse(localStorage.user);
    var application=JSON.parse(localStorage.application);
    var data={
        "action": "addVersion",
        "versionname": $('#Name').val(),
        "short":$('#Short').val(),
        "version": $('#Version').val(),
        "id": user.iduser,
        "idapp": application.idapplication,
        "file":file
    }
    PostAPI(data,function(result){
        getApplicationById(); 
        $('.modal-body').text(result.message);
        $('#logoutModal').modal('show'); 
        // alert(result.message);
        // if(!alert(result.message)){
        //     window.location.href="dashboard.html";
        // }
        
    })
}

