package com.haris.update;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private long downloadID = -1;
    private DownloadManager downloadManager;
    private TextView dialogTitle;
    private AlertDialog downloadDialog;
    private Handler progressHandler,updateHandler;
    private final int PERMISSION_REQUEST_CODE = 123123;

    private final boolean showCarScreen = true;

    private static final String DOWNLOAD_FILENAME = "haris_update.apk";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        registerReceiver(downloadReceiver,new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        ListView listView = new ListView(this);
        listView.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1){
            @Override
            public int getCount() {
                return 100;
            }

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                if(convertView == null){
                    convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_1,parent,false);
                }

                ((TextView) convertView).setText(getString(R.string.item_title,position+1));

                return convertView;
            }
        });

        if(showCarScreen){
            setContentView(R.layout.activity_update);
        }
        else {
            setContentView(listView);
        }

        updateHandler = new Handler();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(downloadReceiver);
        if(progressHandler != null){
            progressHandler.removeCallbacks(downloadProgress);
            progressHandler = null;
        }

        if(updateHandler != null){
            updateHandler.removeCallbacks(updateRun);
            updateHandler = null;
        }

        if(downloadID>-1){
            downloadManager.remove(downloadID);
        }
    }

    private void showToast(String msg){
        if(msg == null){
            msg = "Empty";
        }
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
    }

    @SuppressLint({"StringFormatInvalid","InflateParams"})
    private void downloadUpdate(String url){

        File downloadPath = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),DOWNLOAD_FILENAME);
        if(downloadPath.exists()){
            try {
                if(!downloadPath.delete()){
                    showToast("cannot remove last updated file.");
                }
            }
            catch (Exception ex){
                ex.printStackTrace();
                showToast("exception occurred on removing last updated file.");
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_progress,null);
        dialogTitle = view.findViewById(R.id.title);
        dialogTitle.setText(getString(R.string.downloading,0));

        builder.setCancelable(false);
        builder.setView(view);

        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setDescription("Downloading...");
        request.setTitle(getString(R.string.app_name));
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, DOWNLOAD_FILENAME);
//        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

        if(downloadManager != null){
            downloadID = downloadManager.enqueue(request);

            downloadDialog = builder.show();
            progressHandler = new Handler();
            progressHandler.postDelayed(downloadProgress,1000);
        }
        else {
            showToast("Unable to download updated build.");
        }
    }

    Runnable updateRun = new Runnable() {

        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    checkUpdate();
                }
            });
        }
    };

    Runnable downloadProgress = new Runnable() {
        @Override
        public void run() {
            DownloadManager.Query q = new DownloadManager.Query();
            q.setFilterById(downloadID);
            Cursor cursor = downloadManager.query(q);
            cursor.moveToFirst();

            int bytes_downloaded = cursor.getInt(cursor
                    .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));

            final int progress = (int) ((bytes_downloaded * 100L) / bytes_total);
            Log.v("Download",progress+"");

            if(dialogTitle != null){
                runOnUiThread(new Runnable() {

                    @SuppressLint("StringFormatInvalid")
                    @Override
                    public void run() {
                        dialogTitle.setText(getString(R.string.downloading,progress));
                    }
                });
            }

            if(progressHandler != null){
                progressHandler.postDelayed(this, 1000);
            }
        }
    };

    private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            downloadDialog.dismiss();
            progressHandler.removeCallbacks(downloadProgress);

            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            if (downloadID == id) {
                DownloadManager.Query query = new DownloadManager.Query();
                query.setFilterById(downloadID);
                Cursor cursor = downloadManager.query(query);
                if (cursor.moveToFirst()) {
                    String path = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
                    openFile(path);
                }
                cursor.close();
            }

            downloadID = -1;
        }
    };

    private void openFile(String path){

        if(Build.VERSION.SDK_INT>=24){
            try{
                Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                m.invoke(null);
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder(); StrictMode.setVmPolicy(builder.build());

//        Uri pathURI = FileProvider.getUriForFile(this, getPackageName() + ".provider",
//                new File(path));

        try {
            Intent install = new Intent(Intent.ACTION_VIEW);
//            install.setDataAndType(pathURI, "application/vnd.android.package-archive");
            install.setDataAndType(Uri.parse(path), "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(install);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Unable to open file...", Toast.LENGTH_SHORT).show();
        }
    }


    private void showUpdateAlert(final String url){
        new AlertDialog.Builder(this)
                .setTitle("Update Available")
                .setMessage("Please download the latest update.")
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        downloadUpdate(url);
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        repeatCheckUpdate();
                    }
                })
                .setCancelable(false)
                .show();
    }

    private void checkUpdate(){

        int permissionID = ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionID != PackageManager.PERMISSION_GRANTED) {

                boolean f = shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE);

                if(f || true){
                    requestPermissions(
                            new String[]{
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.READ_EXTERNAL_STORAGE
                            },
                            PERMISSION_REQUEST_CODE);
                }
                else {
                    showToast("Please allow permission for download the update from app settings.");

                }

                return;
            }
        }

        VolleyLog.DEBUG = true;

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, "http://harisferoz.com/api/service.php",
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    String latestBuildUrl = null;

                    try {
                        JSONObject obj = new JSONObject(response);

                        PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                        int currentVersion = getVersionNumber(pInfo.versionName);

                        if(obj.getBoolean("success")){

                            JSONArray arr = obj.getJSONArray("data");
                            for(int i=0;i<arr.length();i++){
                                JSONObject item = arr.getJSONObject(i);
                                if(currentVersion<getVersionNumber(item.getString("version"))){
                                    latestBuildUrl = item.getString("link");
                                }
                            }
                        }
                        else {
//                            showToast("Invalid response: "+response);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        showToast("Unable to parse response: "+response);
                    }

                    if(latestBuildUrl != null){
                        showUpdateAlert(latestBuildUrl);
                    }
                    else {
                        repeatCheckUpdate();
                    }

                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    showToast(error.getLocalizedMessage());
                    repeatCheckUpdate();
                }
            }
        ) {

            @SuppressLint("HardwareIds")
            @Override
            protected Map<String, String> getParams() {

                String packageName = "-";
                String deviceID = Settings.Secure.getString(getContentResolver(),
                        Settings.Secure.ANDROID_ID);

                try {
                    PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                    packageName = pInfo.packageName;
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }

                Map<String,String> params = new HashMap<>();
                params.put("action","getApplicationsByKey");
                params.put("key","5da6f902ac307");
                params.put("deviceid", deviceID);
                params.put("package",packageName);
                return params;
            }

        };

        queue.add(request);
    }

    private void repeatCheckUpdate(){
        if(updateHandler != null){
            // 5 secs delay
            updateHandler.postDelayed(updateRun, 5 *1000);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        repeatCheckUpdate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(updateHandler != null){
            updateHandler.removeCallbacks(updateRun);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PERMISSION_REQUEST_CODE){
            checkUpdate();
        }
    }

    private int getVersionNumber(String versionName){
        String[] v = versionName.split("\\.",0);
        int count=0;
        for(int i=0;i<v.length;i++){
            try {
                count += Integer.parseInt(v[i])+(i*10);
            }
            catch (NumberFormatException ignored){ }
        }
        return count;
    }
}
