<?php
header("Access-Control-Allow-Origin: *");
$target_dir = "uploads/";
$base64_string = $_POST['image'];
$d = new DateTime();
$filenam = $d->format('Y-m-d\-H-i-s').'.apk';
$target_file = $target_dir . basename($filenam);

$uploaded = file_put_contents($target_file, file_get_contents($base64_string));
if ($uploaded) {  
    $response = array("success" => true, "message" => "File Uploaded Successfully.", "File" => basename($filenam));
} else {
    $response = array("success" => false, "message" => "Please try again");
}
$result = json_encode($response, true);
echo $result;
?>