<?php
header("Access-Control-Allow-Origin: *");
$target_dir = "uploads/";
$d = new DateTime();
// echo $d->format('Y-m-d\-H-i-s');
$target_file1 = $target_dir . basename($_FILES["fileName"]["name"]);
$imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
// $filenam = rand(0000, 99999).'.'.$imageFileType1;
$filenam = $d->format('Y-m-d\-H-i-s').'.'.$imageFileType1;
$target_file = $target_dir . basename($filenam);
$uploadOk = 1;
if (file_exists($filenam)) {
    $response = array("success" => false, "message" => "Sorry, file already exists.");
    $uploadOk = 0;
}
if($imageFileType1 != "apk" && $_POST['imageName'] == "apk" ) {
    // echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $response = array("success" => false, "message" => "Sorry, only apk files are allowed.");
    $uploadOk = 0;
}

if ($uploadOk == 0) {
    echo '2';
    $result = json_encode($response, true);
    echo $result;
} 
else {
    $uploaded = move_uploaded_file($_FILES["fileName"]["tmp_name"], $target_file);
    if ($uploaded) {  
        $response = array("success" => true, "message" => "File Uploaded Successfully.", "File" => basename($filenam));
    } else {
        $response = array("success" => false, "message" => "Please try again");
    }
    $result = json_encode($response, true);
    echo $result;
}
?>