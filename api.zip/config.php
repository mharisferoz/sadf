<?php

session_start();
// $mysql_connect = mysqli_connect("127.0.0.1","root","password","sadf");
$mysql_connect = mysqli_connect("127.0.0.1","herisfer_sadf","R0ymE2RuX5TMdOp","herisfer_sadf");



if (!$mysql_connect) {
    // echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    // echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    die("Error: Unable to connect to MySQL." . PHP_EOL);
}

//mysqli_close($mysql_connect);
?>
