<?php
// header("access-control-allow-origin: *");
header("Access-Control-Allow-Origin: *");
include("config.php");

$action = $_POST["action"];

switch ($action) {


    case "email":
        $to = "k153420@nu.edu.pk";
        $subject = "Registation On Secure App Deployment Framework";
        $message = "<html><head><title>Registation On Secure App Deployment Framework</title></head><body>
        <p>Dear " . $name . "!</p>
        <p>Welcome to Secure App Deployment Framework. Your account is registered.</p></body></html>";
        // <p>Welcome to Bamigbe Network. Please wait for Admin Team Approval. Your confirmation code is  ".$code."</p></body></html>";
        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: admin@bamigbe.com' . "\r\n";
        // $headers .= 'Bcc: admin@bamigbe.com' . "\r\n";
        mail($to, $subject, $message, $headers);
        $response = array("success" => true, "message" => "email sent");
        $result = json_encode($response, true);
        echo $result;
        break;
    case "login":
        $email = $_POST["email"];
        $password = $_POST["password"];
        $sql1 = "Select * from user where email = '" . $email . "' and password = '" . $password . "'";
        $query = mysqli_query($mysql_connect, $sql1);
        if (mysqli_num_rows($query) > 0) {
            $get_row = mysqli_fetch_assoc($query);
            $response = array("success" => true, "message" => "You have logged in successfully", "user" => $get_row);
        } else {
            $response = array("success" => false, "message" => "Invalid Email or Password", "user_id" => "");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "signup":
        $name = (isset($_POST["name"])) ? $_POST["name"] : "";
        $email = (isset($_POST["email"])) ? $_POST["email"] : "";
        $mobile = (isset($_POST["mobile"])) ? $_POST["mobile"] : "";
        $address = (isset($_POST["address"])) ? $_POST["address"] : "";
        $username = (isset($_POST["username"])) ? $_POST["username"] : "";
        $password = (isset($_POST["password"])) ? $_POST["password"] : "";
        $dob = (isset($_POST["dob"])) ? $_POST["dob"] : "";
        $image = ($_POST["image"]) ? $_POST["image"] : "";

        $sql1 = "Select * from user where email = '" . $email . "';";
        $query = mysqli_query($mysql_connect, $sql1);
        $result = '';

        if (mysqli_num_rows($query) > 0) {
            $response = array("success" => false, "message" => "User Already Exist", "user_id" => "");
            $result = json_encode($response, true);
            echo $result;
        } else {

            $sql = "INSERT INTO user (`name`,`email`,`mobile`,`address`,`active`,`username`,`password`,`dob`,`image`) VALUES ('$name', '$email',  '$mobile', '$address',1, '$username', '$password','$dob', '$image')";
            // $code = rand(00000,99999);
            $query1 = mysqli_query($mysql_connect, $sql);
            $sqlid = "select * from user where email = '" . $email . "'";
            $resultid = mysqli_query($mysql_connect, $sqlid);
            $user_id = '';
            if (mysqli_num_rows($resultid) > 0) {
                while ($row = mysqli_fetch_array($resultid)) {
                    // $user_id= $row['id'];
                    $user_data = $row;
                }
            }
            if ($query1) {
                // $response = array("success" => true, "message" => "Your Account created succefully","user_id"=>$user_id);
                $response = array("success" => true, "message" => "Your Account created succefully", "user_id" => $user_data);
                // $sql2 = "INSERT INTO tbl_code (`user_id`,`code`,`status`) VALUES ('$user_id', '$code', '1')";
                // $query2 = mysqli_query($mysql_connect, $sql2);

                $to = $email;
                $subject = "Registation On Secure App Deployment Framework";
                $message = "<html><head><title>Registation On Secure App Deployment Framework</title></head><body>
                <p>Dear " . $name . "!</p>
                <p>Welcome to Secure App Deployment Framework. Your account is registered.</p></body></html>";
                // <p>Welcome to Bamigbe Network. Please wait for Admin Team Approval. Your confirmation code is  ".$code."</p></body></html>";
                // Always set content-type when sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: mharisferoz@gmail.com' . "\r\n";
                // $headers .= 'Bcc: admin@bamigbe.com' . "\r\n";
                mail($to, $subject, $message, $headers);

                // if(strpos($mobile_no, "+")==false){
                //     $mobile_no="+".$mobile_no;
                //     $client->messages->create(
                //         $mobile_no,
                //         array(
                //             'from' => $twilio_number,
                //             'body' => 'Welcome to Bamigbe Network. Please wait for Admin Team Approval. Your confirmation code is  "'.$code.'" '
                //         )
                //     );
                // }
                // else{
                //     $client->messages->create(
                //         $mobile_no,
                //         array(
                //             'from' => $twilio_number,
                //             'body' => 'Welcome to Bamigbe Network. Please wait for Admin Team Approval. Your confirmation code is  "'.$code.'" '
                //         )
                //     );
                // }
                $result = json_encode($response, true);
                echo $result;
            } else {
                $response = array("success" => false, "message" => "Please Try Again", "user_id" => "");
                $result = json_encode($response, true);
                echo $result;
                break;
            }
        }

        break;
    case "upload_profile_image":
        $target_dir = "uploads/";
        $file_name = rand(0000, 99999) . basename($_FILES["logo"]["name"]);
        $target_file_name = $target_dir . $file_name;
        $response = array();

        // Check if image file is a actual image or fake image
        if (isset($_FILES["logo"])) {
            if (move_uploaded_file($_FILES["logo"]["tmp_name"], $target_file_name)) {
                $success = true;
                $message = "Successfully Uploaded";
                $file_name = $target_file_name;
            } else {
                $success = false;
                $message = "Error while uploading";
                $file_name = "";
            }
        } else {
            $success = false;
            $message = "Required Field Missing";
            $file_name = "";
        }
        $response["success"] = $success;
        $response["message"] = $message;
        $response["filename"] = $file_name;

        $result = json_encode($response, true);
        echo $result;
        break;
    case "code_verification":
        $user_id = $_POST["user_id"];
        $code = $_POST["code"];
        $sql1 = "Select * from tbl_code where user_id = '" . $user_id . "' and code ='" . $code . "' and status = '1'";
        $query = mysqli_query($mysql_connect, $sql1);
        $result = mysql_fetch_assoc($query);
        $code_id = $result["id"];
        if (mysqli_num_rows($query) > 0) {
            // $sql = "UPDATE tbl_code set status = '0' where id = '" . $code_id . "'";
            // $query = mysqli_query($mysql_connect, $sql);
            $response = array("success" => true, "message" => "Thank you for registering on Bamigbe. For the safety of all users, new accounts are verified and approved by our admin team. Please wait for confirmation email before login in", "user_id" => $user_id);
        } else {
            $response = array("success" => false, "message" => "Code is Invalid", "user_id" => "");
        }
        $result = json_encode($response, true);
        echo $result;
        break;

    case "verification":
        $user_id = $_POST["user_id"];
        $mobile_no = $_POST["mobile_no"];
        $sql1 = "Select * from tbl_user where mobile_no = '" . $mobile_no . "'";
        $query = mysqli_query($mysql_connect, $sql1);

        //echo $sql1;

        if (mysqli_num_rows($query) > 0) {
            $response = array("success" => false, "message" => "Mobile Number Already Exist", "user_id" => "");
        } else {
            $sql = "UPDATE tbl_user set mobile_no = '" . $mobile_no . "', is_verified = '1' where id = '" . $user_id . "'";

            $query = mysqli_query($mysql_connect, $sql);
            if ($query) {
                $response = array("success" => true, "message" => "Your Mobile number added succefully", "user_id" => $user_id);
            } else {
                $response = array("success" => false, "message" => "Please Try Again", "user_id" => "");
            }
        }

        $result = json_encode($response, true);

        echo $result;
        break;
    case "forgot_password":
        $email = $_POST["email"];

        $sql1 = "Select * from tbl_user where email = '" . $email . "'";
        $query = mysqli_query($mysql_connect, $sql1);

        if (mysqli_num_rows($query) > 0) {

            $get_row = mysqli_fetch_assoc($query);

            $to = $get_row["email"];
            $subject = "Forgot Password";
            $message = "<html>
                <head>
                <title>Forgot Password</title>
                </head>
                <body>
                <p>Dear Customer!</p>
                <p>Thank you for usng Bamigbe. Please Login with your account. Your Email: " . $get_row["email"] . " and Password: " . $get_row["password"] . "</p>
                </body>
                </html>
                ";

            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers<
            $headers .= 'From: admin@bamigbe.com' . "\r\n";
            $headers .= 'Bcc: admin@bamigbe.com' . "\r\n";

            mail($to, $subject, $message, $headers);



            $response = array("success" => true, "message" => "Mail has been sent ", "user_id" => $get_row["id"]);
        } else {
            $response = array("success" => false, "message" => "Invalid Email and Password", "user_id" => "");
        }


        $result = json_encode($response, true);
        echo $result;
        break;
    case "reset_password":
        $user_id = $_POST["user_id"];
        $password = $_POST["password"];

        $sql = "UPDATE tbl_user set password = '" . $password . "' where id = '" . $user_id . "'";
        $query = mysqli_query($mysql_connect, $sql);
        if ($query) {
            $response = array("success" => true, "message" => "Your Password has been reset succefully", "user_id" => $user_id);
        } else {
            $response = array("success" => false, "message" => "Please Try Again", "user_id" => "");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getNewVersion":
        $idapp = $_POST["idapp"];
        $sql1 = "SELECT version FROM versions ver where ver.idapplication = '" . $idapp . "' ORDER BY ver.idversions DESC LIMIT 1";
        $query = mysqli_query($mysql_connect, $sql1);
        if(mysqli_num_rows($query) > 0){
              $row = mysqli_fetch_array($query);
              $newVersion = explode(".", $row[0]);
              $firstval = "";
              $incval = "";
              if(intval($newVersion[2]) == 9){
                $firstval = intval($newVersion[0])+1;
                $incval = '0';
              }
              else{
                $firstval = $newVersion[0];
                $incval = intval($newVersion[2])+1; 
              }
              $newVersion = $firstval.'.'.$newVersion[1].'.'.$incval;
              $response["success"] = true;
              $response["data"] = array('version' => $newVersion);
        }
        else{
            $response["success"] = true;
            $response["data"] = array('version' => "1.0.0"); 
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "addApplication":
        $name = (isset($_POST["name"])) ? $_POST["name"] : "";
        $description = (isset($_POST["description"])) ? $_POST["description"] : "";
        $logo = (isset($_POST["logo"])) ? $_POST["logo"] : "";
        $sc1 = (isset($_POST["sc1"])) ? $_POST["sc1"] : "";
        $sc2 = (isset($_POST["sc2"])) ? $_POST["sc2"] : "";
        $sc3 = (isset($_POST["sc3"])) ? $_POST["sc3"] : "";
        $category = (isset($_POST["category"])) ? $_POST["category"] : "";
        $web = (isset($_POST["web"])) ? $_POST["web"] : "";
        // $version = (isset($_POST["version"])) ? $_POST["version"] : "";
        $date = date("d-m-Y");
        $iduser = (isset($_POST["id"])) ? $_POST["id"] : "";
        $uuid = uniqid();

        $sql1 = "Select * from application where name = '" . $name . "';";
        $query = mysqli_query($mysql_connect, $sql1);
        $result = '';
        if (mysqli_num_rows($query) > 0) {
            $response = array("success" => false, "message" => "Application Already Exist");
            $result = json_encode($response, true);
            echo $result;
        } else {
            $sql = "INSERT INTO application (`name`,`description`,`logo`,`sc1`,`sc2`,`sc3`,`category`,`web`,`iduser`,`date`,`uniqueKey`) VALUES ('$name', '$description', '$logo', '$sc1', '$sc2', '$sc3', '$category', '$web','$iduser', '$date','$uuid')";
            $query1 = mysqli_query($mysql_connect, $sql);
            if ($query1) {
                $response = array("success" => true, "message" => "Application created succefully");
                $result = json_encode($response, true);
                echo $result;
                // $sqlsel = "select idapplication from application where name = '" . $name . "'";
                // $querysel = mysqli_query($mysql_connect, $sqlsel);
                // if ($querysel) {
                //     while ($row = mysqli_fetch_assoc($querysel)) {
                //         $idapplication = $row["idapplication"];
                //     }
                //     $sqlins = "INSERT INTO versions (`versionname`,`version`,`idapplication`,`iduser`) VALUES ('" . $name . '.apk' . "', '$version','$idapplication', '$iduser')";
                //     $queryins = mysqli_query($mysql_connect, $sqlins);
                //     if ($queryins) {
                //         $response = array("success" => true, "message" => "Application created succefully");
                //         $result = json_encode($response, true);
                //         echo $result;
                //     } else {
                //         $response = array("success" => true, "message" => "App id is not availabe");
                //         $result = json_encode($response, true);
                //         echo $result;
                //     }
                // } else {
                //     $response = array("success" => true, "message" => "App id is not availabe");
                //     $result = json_encode($response, true);
                //     echo $result;
                // }
            } else {
                $response = array("success" => false, "message" => "Please Try Again");
                $result = json_encode($response, true);
                echo $result;
            }
        }
        break;
    case "addVersion":
        // $versionname = (isset($_POST["versionname"])) ? $_POST["versionname"] : "";
        $versionname = "";
        $version = (isset($_POST["version"])) ? $_POST["version"] : "";
        $short = (isset($_POST["version"])) ? $_POST["short"] : "";
        $date = date("d-m-Y");
        $iduser = (isset($_POST["id"])) ? $_POST["id"] : "";
        $idapp = (isset($_POST["idapp"])) ? $_POST["idapp"] : "";
        $file = (isset($_POST["file"])) ? $_POST["file"] : "";

        $sqlins = "INSERT INTO versions (`versionname`,`short`,`version`,`idapplication`,`iduser`,`file`) VALUES ('$versionname','$short', '$version','$idapp', '$iduser','$file')";
        $queryins = mysqli_query($mysql_connect, $sqlins);
        if ($queryins) {
            $response = array("success" => true, "message" => "Version added succefully");
            $result = json_encode($response, true);
            echo $result;
        } else {
            $response = array("success" => true, "message" => "App id is not availabe");
            $result = json_encode($response, true);
            echo $result;
        }

        // $sql1 = "Select * from versions where versionname = '" . $versionname . "' or version = '" . $version . "';";
        // $query = mysqli_query($mysql_connect, $sql1);
        // $result = '';
        // if (mysqli_num_rows($query) > 0) {
        //     $response = array("success" => false, "message" => "Version Already Exist");
        //     $result = json_encode($response, true);
        //     echo $result;
        // } else {

        //     $sqlins = "INSERT INTO versions (`versionname`,`short`,`version`,`idapplication`,`iduser`,`file`) VALUES ('$versionname','$short', '$version','$idapp', '$iduser','$file')";
        //     $queryins = mysqli_query($mysql_connect, $sqlins);
        //     if ($queryins) {
        //         $response = array("success" => true, "message" => "Version added succefully");
        //         $result = json_encode($response, true);
        //         echo $result;
        //     } else {
        //         $response = array("success" => true, "message" => "App id is not availabe");
        //         $result = json_encode($response, true);
        //         echo $result;
        //     }
        // }
        break;
    case "deleteApplication":
        $iduser = $_POST["iduser"];
        $idapplication = $_POST["idapplication"];
        $sql = "delete from application where idapplication = '" . $idapplication . "' and iduser = '" . $iduser . "'";
        $query = mysqli_query($mysql_connect, $sql);
        if ($query) {
            $sql1 = "delete from versions where idapplication = '" . $idapplication . "' and iduser = '" . $iduser . "'";
            $query1 = mysqli_query($mysql_connect, $sql1);
            if ($query1) {
                $response = array("success" => true, "message" => "Application Deleted successfully.");
            } else {
                $response = array("success" => false, "message" => "Please try again");
            }
        } else {
            $response = array("success" => false, "message" => "Please try");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
        case "deleteApplication":
        $iduser = $_POST["iduser"];
        $idapplication = $_POST["idapplication"];
        $sql = "delete from application where idapplication = '" . $idapplication . "' and iduser = '" . $iduser . "'";
        $query = mysqli_query($mysql_connect, $sql);
        if ($query) {
            $sql1 = "delete from versions where idapplication = '" . $idapplication . "' and iduser = '" . $iduser . "'";
            $query1 = mysqli_query($mysql_connect, $sql1);
            if ($query1) {
                $response = array("success" => true, "message" => "Application Deleted successfully.");
            } else {
                $response = array("success" => false, "message" => "Please try again");
            }
        } else {
            $response = array("success" => false, "message" => "Please try");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "deleteVersion":
        $iduser = $_POST["iduser"];
        $idversions = $_POST["idversions"];
        $sql = "delete from versions where idversions = '" . $idversions . "' and iduser = '" . $iduser . "'";
        $query = mysqli_query($mysql_connect, $sql);
        if ($query) {
            $response = array("success" => true, "message" => "Version Deleted successfully.");
            
        } else {
            $response = array("success" => false, "message" => "Please try");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getAllApplications":
        $sql1 = "SELECT * FROM application app, versions ver where app.iduser=ver.iduser and app.idapplication=ver.idapplication ORDER BY ver.idversions DESC LIMIT 1";

        $query = mysqli_query($mysql_connect, $sql1);
        $response["data"] = array();
        if (mysqli_num_rows($query) > 0) {
            // $i = 0;
            while ($row = mysqli_fetch_assoc($query)) {
                $posts["idapplication"] = $row["idapplication"];
                $posts["name"] = $row["name"];
                $posts["description"] = $row["description"];
                $posts["uniqueKey"] = $row["uniqueKey"];
                $posts["iduser"] = $row["iduser"];
                $posts["date"] = $row["date"];
                $posts["idversions"] = $row["idversions"];
                $posts["versionname"] = $row["versionname"];
                $posts["version"] = $row["version"];
                array_push($response["data"], $posts);
                // $i++;
            }

            // array_push($response["data"], $posts);

            // success
            $response["success"] = true;
            $response["count"] = mysqli_num_rows($query);
        } else {
            $response = array("success" => true, "message" => "No Result Found", "data" => array());
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getApplications":
        $user_id = $_POST["id"];
        $sql1 = "SELECT * FROM application app, versions ver where app.iduser=ver.iduser and app.idapplication=ver.idapplication and app.iduser = '" . $user_id . "' ORDER BY ver.idversions DESC LIMIT 1";

        $query = mysqli_query($mysql_connect, $sql1);
        $response["data"] = array();
        if (mysqli_num_rows($query) > 0) {
            // $i = 0;
            while ($row = mysqli_fetch_assoc($query)) {
                $posts["idapplication"] = $row["idapplication"];
                $posts["name"] = $row["name"];
                $posts["description"] = $row["description"];
                $posts["uniqueKey"] = $row["uniqueKey"];
                $posts["iduser"] = $row["iduser"];
                $posts["date"] = $row["date"];
                $posts["idversions"] = $row["idversions"];
                $posts["versionname"] = $row["versionname"];
                $posts["version"] = $row["version"];
                array_push($response["data"], $posts);
                // $i++;
            }

            // array_push($response["data"], $posts);

            // success
            $response["success"] = true;
            $response["count"] = mysqli_num_rows($query);
        } else {
            $response = array("success" => true, "message" => "No Result Found", "data" => array());
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getApplicationsOnly":
            $user_id = $_POST["id"];
            $sql1 = "SELECT * FROM application app where app.iduser = '" . $user_id . "'";
    
            $query = mysqli_query($mysql_connect, $sql1);
            $response["data"] = array();
            if (mysqli_num_rows($query) > 0) {
                // $i = 0;
                while ($row = mysqli_fetch_assoc($query)) {
                    $posts["idapplication"] = $row["idapplication"];
                    $posts["name"] = $row["name"];
                    $posts["description"] = $row["description"];
                    $posts["uniqueKey"] = $row["uniqueKey"];
                    $posts["iduser"] = $row["iduser"];
                    $posts["date"] = $row["date"];
                    $posts["idversions"] = $row["idversions"];
                    $posts["versionname"] = $row["versionname"];
                    $posts["version"] = $row["version"];
                    array_push($response["data"], $posts);
                    // $i++;
                }
    
                // array_push($response["data"], $posts);
    
                // success
                $response["success"] = true;
                $response["count"] = mysqli_num_rows($query);
            } else {
                $response = array("success" => true, "message" => "No Result Found", "count" => mysqli_num_rows($query));
            }
            $result = json_encode($response, true);
            echo $result;
            break;
    case "getApplicationsById":
        $user_id = $_POST["id"];
        $idapp = $_POST["idapp"];
        $sql1 = "SELECT * FROM application app, versions ver where app.iduser=ver.iduser and app.idapplication=ver.idapplication and app.iduser = '" . $user_id . "' and app.idapplication = '" . $idapp . "'";
        $query = mysqli_query($mysql_connect, $sql1);
        $response["data"] = array();
        if (mysqli_num_rows($query) > 0) {
            // $i = 0;
            while ($row = mysqli_fetch_assoc($query)) {
                $posts["idapplication"] = $row["idapplication"];
                $posts["name"] = $row["name"];
                $posts["description"] = $row["description"];
                $posts["uniqueKey"] = $row["uniqueKey"];
                $posts["iduser"] = $row["iduser"];
                $posts["date"] = $row["date"];
                $posts["idversions"] = $row["idversions"];
                $posts["versionname"] = $row["versionname"];
                $posts["version"] = $row["version"];
                $posts["link"] = "http://secureappdeployment.epizy.com/api/uploads/".$row["file"];
                array_push($response["data"], $posts);
                // $i++;
            }

            // array_push($response["data"], $posts);

            // success
            $response["success"] = true;
            $response["count"] = mysqli_num_rows($query);
        } else {
            $response = array("success" => false, "message" => "No Result Found", "data" => array());
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getApplicationsByKey":
        $key = $_POST["key"];
        $deviceid = $_POST["deviceid"];
        // $sql2 = "SELECT * FROM application app, versions ver where app.iduser=ver.iduser and app.idapplication=ver.idapplication and app.uniqueKey='" . $key . "' ORDER BY ver.idversions DESC LIMIT 1";
        $sql2 = "SELECT * FROM application app, versions ver,devices dev where app.iduser=ver.iduser and app.idapplication=ver.idapplication and ver.idapplication = dev.idapplication and app.uniqueKey='". $key ."' and dev.deviceid = '".$deviceid."' and dev.active = 1 ORDER BY ver.idversions DESC LIMIT 1";
        $query2 = mysqli_query($mysql_connect, $sql2);
        $response["data"] = array();
        $idapplication = "";
        $idversion = "";
        if (mysqli_num_rows($query2) > 0) {
            while ($row = mysqli_fetch_assoc($query2)) {
                $idapplication = $row["idapplication"];
                $idversion = $row["idversions"];
                $posts["name"] = $row["name"];
                $posts["date"] = $row["date"];
                $posts["versionname"] = $row["versionname"];
                $posts["version"] = $row["version"];
                $posts["link"] = "http://harisferoz.com/api/uploads/".$row["file"];
                array_push($response["data"], $posts);
            }
            $response["success"] = true;
            // new
            $sql1 = "Select count(deviceid) as count from devices where deviceid = '" . $deviceid . "';";
            $query1 = mysqli_query($mysql_connect, $sql1);
            if (mysqli_num_rows($query1) > 0) {
                $count = 0;
                while ($row = mysqli_fetch_assoc($query1)) {
                    $count = $row["count"];
                }
                if($count == 0 ){
                    $sql3 = "INSERT INTO devices (`id`,`deviceid`,`idapplication`,`idversion`,`active`) VALUES ('', '$deviceid', '$idapplication', '$idversion',0)";
                    $query3 = mysqli_query($mysql_connect, $sql3);
                }
            }
            // new
        } 
        else {
            $response = array("success" => false, "message" => "No Update Available");
            $sql4 = "SELECT * FROM application app, versions ver where app.iduser=ver.iduser and app.idapplication=ver.idapplication and app.uniqueKey='". $key ."' ORDER BY ver.idversions DESC LIMIT 1";
            $query4 = mysqli_query($mysql_connect, $sql4);
            if (mysqli_num_rows($query4) > 0) {
                while ($row = mysqli_fetch_assoc($query4)) {
                    $idapplication = $row["idapplication"];
                    $idversion = $row["idversions"];
                }
                $sql1 = "Select count(deviceid) as count from devices where deviceid = '" . $deviceid . "';";
                $query1 = mysqli_query($mysql_connect, $sql1);
                if (mysqli_num_rows($query1) > 0) {
                    $count = 0;
                    while ($row = mysqli_fetch_assoc($query1)) {
                        $count = $row["count"];
                    }
                    if($count == 0 ){
                        $sql3 = "INSERT INTO devices (`id`,`deviceid`,`idapplication`,`idversion`,`active`) VALUES ('', '$deviceid', '$idapplication', '$idversion',0)";
                        $query3 = mysqli_query($mysql_connect, $sql3);
                    }
                }
            }
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getDevices":
        $idapplication = $_POST["idapplication"];
        $sql1 = "Select * from devices where idapplication='".$idapplication."'";
        $query = mysqli_query($mysql_connect, $sql1);
        $response["data"] = array();
        if (mysqli_num_rows($query) > 0) {
            while ($row = mysqli_fetch_assoc($query)) {
                $posts['id'] = $row['id'];
                $posts['deviceid'] = $row['deviceid'];
                $posts['idapplication'] = $row['idapplication'];
                $posts['idversion'] = $row['idversion'];
                array_push($response["data"], $posts);
            }
            $response["success"] = true;
        } else {
            $response = array("success" => true, "message" => "No Result Found");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "updateDevices":
        $id = $_POST["id"];
        $sql = "UPDATE devices SET active = 1 WHERE id IN ($id)";
        $query = mysqli_query($mysql_connect, $sql);
        if ($query) {
            $response = array("success" => true, "message" => "Distributed successfully");
        } else {
            $response = array("success" => false, "message" => "Please Try Again");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "getProfile":

        $user_id = $_POST["user_id"];
        $sql1 = "Select * from tbl_user tp where id = '" . $user_id . "'";

        $query = mysqli_query($mysql_connect, $sql1);

        if (mysqli_num_rows($query) > 0) {
            $i = 0;
            $row = mysqli_fetch_assoc($query);

            $response["user"] = $row;
            $sqlrating = "SELECT AVG(rate) as 'rating' FROM tbl_rating where user_id = '" . $row["id"] . "'";
            $querycount = mysqli_query($mysql_connect, $sqlrating);
            if (mysqli_num_rows($querycount) > 0) {
                $rowcount = mysqli_fetch_array($querycount);
                $response["user"]["rating"] = round($rowcount["rating"], 0);
            } else {
                $response["user"]["rating"] = 1;
            }



            // success
            $response["success"] = true;
            $response["error"] = false;
            $response["count"] = mysqli_num_rows($query);
        } else {
            $response = array("success" => true, "message" => "No Result Found", "count" => mysqli_num_rows($query));
        }
        $result = json_encode($response, true);
        echo $result;
        break;

    case "editProfile":
        $user_id = $_POST["id"];
        $name = (isset($_POST["name"])) ? $_POST["name"] : "";
        $email = (isset($_POST["email"])) ? $_POST["email"] : "";
        $mobile = (isset($_POST["mobile"])) ? $_POST["mobile"] : "";
        $address = (isset($_POST["address"])) ? $_POST["address"] : "";
        $dob = (isset($_POST["dob"])) ? $_POST["dob"] : "";
        $username = (isset($_POST["username"])) ? $_POST["username"] : "";
        $image = ($_POST["image"]) ? $_POST["image"] : "";
        $password = ($_POST["password"]) ? $_POST["password"] : "";

        $sql1 = "Select * from user where iduser = '" . $user_id . "'";
        // echo $sql1;
        // break;
        $query = mysqli_query($mysql_connect, $sql1);
        if (mysqli_num_rows($query) == 0) {
            $response = array("success" => false, "message" => "Inalid user", "user_id" => "");
        } else {

            $sql = "Update user set name = '" . $name . "', email = '" . $email . "', address = '" . $address . "',  dob = '" . $dob . "', image = '" . $image . "', mobile = '" . $mobile . "', username = '" . $username . "', password = '" . $password . "' where iduser = '" . $user_id . "'";
            // echo $sql;
            // break;
            $query = mysqli_query($mysql_connect, $sql);


            if ($query) {
                $response = array("success" => true, "message" => "Your Account updated succefully", "user_id" => $user_id);
            } else {
                $response = array("success" => false, "message" => "Please Try Again", "user_id" => "");
            }
        }
        $result = json_encode($response, true);
        echo $result;
        break;


    case "search":
        $pickup_country = (isset($_POST["pickup_country"])) ? $_POST["pickup_country"] : "";
        $pickup_city = (isset($_POST["pickup_city"])) ? $_POST["pickup_city"] : "";
        $deliver_country = (isset($_POST["delivery_country"])) ? $_POST["delivery_country"] : "";
        $delivery_city = (isset($_POST["delivery_city"])) ? $_POST["delivery_city"] : "";
        $delivery_date = (isset($_POST["delivery_date"])) ? $_POST["delivery_date"] : "";

        $sql1 = "Select * from tbl_post where (pickup_point like '%" . $pickup_country . "%' AND pickup_point like '%" . $pickup_city . "%') 
      AND (delivery_point like '%" . $deliver_country . "%' AND delivery_point like '%" . $delivery_city . "%') AND delivery_date = '" . $delivery_date . "'";

        $query = mysqli_query($mysql_connect, $sql1);
        $response["post"] = array();
        if (mysqli_num_rows($query) > 0) {
            $i = 0;
            while ($row = mysqli_fetch_assoc($query)) {

                $posts[$i] = array();
                $posts[$i]["package_id"] = $row["id"];
                $posts[$i]["title"] = $row["title"];
                $posts[$i]["description"] = $row["description"];
                $posts[$i]["pickup_point"] = $row["pickup_point"];
                $posts[$i]["delivery_date"] = $row["delivery_date"];
                $posts[$i]["delivery_point"] = $row["delivery_point"];
                $posts[$i]["delivery_to"] = $row["delivery_to"];
                $posts[$i]["status"] = $row["is_active"];
                $i++;
            }
            array_push($response["post"], $posts);

            // success
            $response["success"] = true;
            $response["error"] = false;
            $response["count"] = mysqli_num_rows($query);
        } else {
            $response = array("success" => true, "message" => "No Result Found", "count" => mysqli_num_rows($query));
        }
        $result = json_encode($response, true);
        echo $result;
        break;




    case "howitworks":
        $category = $_POST["category"];
        $sql1 = "Select * from how_it_works where category = '" . $category . "'";
        $query = mysqli_query($mysql_connect, $sql1);
        if (mysqli_num_rows($query) > 0) {
            $i = 0;
            $row = mysqli_fetch_assoc($query);
            $response["how_it_works"] = $row;
            // success
            $response["success"] = true;
            $response["error"] = false;
        } else {
            $response = array("success" => true, "message" => "No Result Found");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "aboutus":
        $category = $_POST["category"];
        $sql1 = "Select * from about_us where category = '" . $category . "'";
        $query = mysqli_query($mysql_connect, $sql1);
        if (mysqli_num_rows($query) > 0) {
            $i = 0;
            $row = mysqli_fetch_assoc($query);
            $response["how_it_works"] = $row;
            // success
            $response["success"] = true;
            $response["error"] = false;
        } else {
            $response = array("success" => true, "message" => "No Result Found");
        }
        $result = json_encode($response, true);
        echo $result;
        break;
    case "searchUsers":
        $sear_id = (isset($_POST["sid"])) ? $_POST["sid"] : "";

        $whereclaus = "";

        if ($sear_id != "") {
            $whereclaus .= "first_name like '%" . $sear_id . "%' OR email like '%" . $sear_id . "%' OR mobile_no like '%" . $sear_id . "%' ";
        }

        if ($whereclaus == "") {
            $response = array("success" => false, "message" => "Please enter keyword for search");
        } else {
            $sql1 = "Select * from tbl_user where $whereclaus";



            $query = mysqli_query($mysql_connect, $sql1);
            $response["users"] = array();

            if (mysqli_num_rows($query) > 0) {
                $i = 0;
                while ($row = mysqli_fetch_assoc($query)) {
                    $posts[$i] = array();
                    $posts[$i]["user_id"] = $row["id"];
                    $posts[$i]["first_name"] = $row["first_name"];
                    $posts[$i]["last_name"] = $row["last_name"];
                    $posts[$i]["email"] = $row["email"];
                    $posts[$i]["password"] = $row["password"];
                    $posts[$i]["address"] = $row["address"];
                    $posts[$i]["city"] = $row["city"];
                    $posts[$i]["state"] = $row["country"];
                    $posts[$i]["date_of_birth"] = $row["date_of_birth"];
                    $posts[$i]["business_name"] = $row["business_name"];
                    $posts[$i]["office_address"] = $row["office_address"];
                    $posts[$i]["description"] = $row["description"];
                    $posts[$i]["mobile_no"] = $row["mobile_no"];
                    $posts[$i]["role"] = $row["role"];
                    $posts[$i]["logo"] = $row["logo"];
                    $posts[$i]["is_active"] = $row["is_active"];
                    $posts[$i]["created_at"] = $row["created_at"];
                    $posts[$i]["is_verified"] = $row["is_verified"];
                    $posts[$i]["is_agree"] = $row["is_agree"];

                    $i++;
                }

                array_push($response["users"], $posts);
                // success
                $response["success"] = true;
                $response["error"] = false;
                $response["count"] = mysqli_num_rows($query);
            } else {
                $response = array("success" => false, "message" => "No Result Found", "count" => mysqli_num_rows($query));
            }
        }
        $result = json_encode($response, true);
        echo $result;
        break;

    default:
        echo "Default";
        break;
}
